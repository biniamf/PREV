#!/bin/bash

apk=$1

mv ${apk} ${apk}_
echo -signing app

jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore google_certificate.keystore -storepass 'android' -keypass 'android' ${apk}_ platform

if [ $? -ne 0 ]; then exit 1 
fi

zipalign -f 4 ${apk}_ ${apk}
if [ $? -ne 0 ]; then exit 1
fi

rm ${apk}_
exit 0

